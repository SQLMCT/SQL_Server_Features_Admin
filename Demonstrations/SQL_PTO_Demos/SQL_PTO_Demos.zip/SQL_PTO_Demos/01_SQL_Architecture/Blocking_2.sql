USE AdventureWorks2019
GO

--Blocking Demo - Session 2
--Diane selects from Person.Person table

SELECT * FROM Person.Person 
