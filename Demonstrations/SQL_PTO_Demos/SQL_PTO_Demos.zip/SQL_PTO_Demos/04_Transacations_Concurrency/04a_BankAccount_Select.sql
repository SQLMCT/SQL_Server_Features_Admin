USE WoodgroveBank

SELECT AcctID, FirstName, LastName, Balance, ModifiedDate
FROM Accounting.BankAccounts

----Reset Amounts
--UPDATE Accounting.BankAccounts
--SET Balance = 500
--WHERE AcctID = 1



